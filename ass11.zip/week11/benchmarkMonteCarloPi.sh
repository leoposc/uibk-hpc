#!/bin/bash
bin/monteCarloPiShmem --n=1000000000
