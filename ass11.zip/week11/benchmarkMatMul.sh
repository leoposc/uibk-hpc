#!/bin/bash
bin/matMulShmem --m=2552 --n=2552 --l=2552
