### Team: Peter Burger, Leo Schmid, Fabian Aster, Marko Zaric

The missing points are due to the overfull cluster

## Multiple Files

### Time 

![time](./saveBufferMFiles_8_8.out.png)

### Troughput

![troughput](./saveBufferMFiles_8_8.out.png)

## Single File Multiple Pointer

### Time 

![time](./saveBuffer1FileMPointer_24_16.out.png)

### Troughput

![troughput](./saveBuffer1FileMPointer_24_16Troughput.png)

## Collective

### Time 

![time](./saveBufferCollective_24_32.out.png)

### Troughput

![troughput](./saveBufferCollective_24_32troughput.png)

## Non Collective

### Time 

![time](./saveBufferNonCollective_16_32.out.png)

### Troughput

![troughput](./saveBufferNonCollective_16_32troughput.png)

## Hybrid

### Time 

![time](./saveBufferHybrid_8_32.out.png)

### Troughput

![troughput](./saveBufferHybrid_8_32troughput.png)