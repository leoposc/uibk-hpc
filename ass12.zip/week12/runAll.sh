

sbatch job_NF.sh
sbatch job_1FMP.sh
sbatch job_collective.sh
sbatch job_non_collective.sh
